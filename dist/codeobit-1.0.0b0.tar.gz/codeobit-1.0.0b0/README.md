# 🎯 codeobit - AI-Powered Interactive Development Environment

**Public Beta v1.0.0-beta** - The ultimate vibe coding experience with AI automation

![codeobit Banner](https://img.shields.io/badge/codeobit-v1.0.0--beta-blue?style=for-the-badge&logo=python)
![Python](https://img.shields.io/badge/python-3.11+-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)
![Status](https://img.shields.io/badge/status-Public%20Beta-orange?style=flat-square)

A comprehensive AI-powered development lifecycle automation tool using Google Gemini 2.5. Experience "vibe coding" with intelligent project automation, MCP design patterns, and complete development workflow integration.

## ✨ Features

### 🔥 codeobit Interactive Experience
Experience the ultimate "vibe coding" environment with AI-powered development automation:

```bash
python main.py interactive
```

Or use the quick launcher:
```bash
python gemini
```

**codeobit Features:**
- 🎨 Beautiful ASCII branding with dynamic themes
- 💬 Natural conversation with MCP design patterns
- 🔄 Project memory and data collection
- ⚡ Intelligent workflow automation
- 🎯 Complete development lifecycle integration
- 🌐 Browser automation and testing
- 🐛 Advanced debugging with AI assistance
- 📊 Token usage tracking and project status

### 🤖 AI-Driven Autonomous Workflow & Planning
Advanced AI capabilities for intelligent project management:

**1. Dependency Prediction:**
- The GeminiClient predicts comprehensive project dependencies
- Automatically structures phases, tasks, milestones, team, and resources
- Analyzes project templates to generate realistic project structures
- Provides detailed task breakdown with effort estimation
- Identifies critical dependencies and potential risks

**2. AI-driven Project Planning:**
- The ProjectCommand uses GeminiClient to generate comprehensive plans
- Creates detailed schedules based on project requirements, team size, and estimated duration
- Generates work breakdown structures (WBS) with task dependencies
- Provides resource allocation and team composition recommendations
- Includes risk assessment and mitigation strategies
- Estimates budgets and timelines with multiple scenarios

### 🛠️ Traditional Commands
- `requirements` - Analyze and manage project requirements
- `design` - Generate system architecture and design documents  
- `code` - AI-powered code generation and analysis
- `test` - Automated testing and test case generation
- `security` - Security analysis and vulnerability scanning
- `docs` - Automated documentation generation
- `project` - Project management and task tracking

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Google Gemini API key

### Setup
1. **Get your API key**: Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. **Initialize the CLI**:
   ```bash
   python main.py init
   ```
3. **Start interactive mode**:
   ```bash
   python main.py interactive
   # or
   python gemini
   ```

### Interactive Mode Examples

```
> Generate requirements for a task management app

> Design a REST API for user authentication  

> Write Python code for JWT token validation

> Create unit tests for the authentication function above

> Review the code for security vulnerabilities
```

### Traditional Mode Examples

```bash
# Generate requirements
echo "Build an e-commerce platform" > description.txt
python main.py requirements generate --input description.txt

# Create system design
python main.py design architecture --input requirements.md --technology "Python/React"

# Generate code
python main.py code generate --input "Create user auth API" --language Python

# Create tests
python main.py test generate --input app.py --framework pytest
```

### AI-Driven Project Planning Examples

```bash
# Initialize AI-powered project with dependency prediction
python main.py project init --name "E-commerce Platform" --template "web" --output ecommerce_project.json

# Generate comprehensive project plan with AI-driven scheduling
python main.py project plan --input requirements.md --team-size 5 --duration "4 months" --output project_plan.md

# Create AI-generated task management structure
python main.py project tasks --input project_plan.md --output task_structure.md

# Generate detailed project timeline with critical path analysis
python main.py project timeline --input project_plan.md --duration "16 weeks" --output timeline.md

# Get AI-powered project estimation
python main.py project estimate --input requirements.md --team-size 5 --output estimation.md

# Generate comprehensive project status report
python main.py project status --input ecommerce_project.json --output status_report.md
```

## 🎨 Interactive Commands

Within interactive mode, use these special commands:

- `/help` - Show available commands
- `/theme [auto|dark|light]` - Change color theme
- `/history` - View session history
- `/clear` - Clear screen
- `/status` - Show system status
- `/quickstart` - Display quick start guide
- `/exit` - Exit interactive mode

## 🏗️ Architecture

The CLI features a modular design with:

- **AI Integration Layer** - Google Gemini API client with multi-model support
- **Interactive Interface** - Conversational AI with context awareness
- **Command Modules** - Specialized handlers for different engineering workflows
- **Configuration Management** - YAML-based settings with environment variables
- **Rich UI** - Beautiful console output with syntax highlighting

## 🔧 Configuration

Configuration is stored in `config/config.yaml` with support for:

- API keys and model selection
- Output formatting preferences
- Project templates and defaults
- UI themes and display options

## 🤝 Workflow Integration

Perfect for:
- **Requirements Engineering** - Generate user stories and acceptance criteria
- **System Design** - Create architecture diagrams and technical specs
- **Code Development** - Generate, analyze, and optimize code
- **Testing** - Create comprehensive test suites
- **Security** - Vulnerability scanning and security analysis
- **Documentation** - Auto-generate API docs and user guides
- **Project Management** - Track progress and manage tasks

## 📊 AI Model Support

- **Default**: Gemini 2.5-flash (fast, efficient)
- **Complex Tasks**: Gemini 2.5-pro (detailed analysis)
- **Auto-routing**: Intelligent model selection based on request type

Experience the future of software engineering with AI assistance at your fingertips!